# Buy or Wait? — AI Financial Decision Agent

Starter repo & solution for **HackerRank Orchestrate: Buy or Wait?**

This package implements an AI-powered financial decision agent that evaluates whether a user can safely afford a requested expense today, with a payment plan, after waiting, or not at all.

---

## 1. Quick Start & Execution

### Prerequisites
- Python 3.10+ (tested on Python 3.12)
- Required libraries: `pandas`, `numpy`, `pillow`

```bash
pip install pandas numpy pillow
```

### Run Predictions on `dataset/requests.csv`
```bash
python code/main.py --data_dir dataset --output output.csv
```
This evaluates all 250 evaluation requests in `dataset/requests.csv` and outputs the compliant predictions to `output.csv` (and syncs `dataset/output.csv`).

### Run Benchmark Evaluation Pipeline
```bash
python code/evaluation/main.py
```
This runs the evaluation suite against the public ground truth benchmark in `dataset/sample_requests.csv` and reports exact-match and MAE accuracy metrics.

### Interactive Purchase Query CLI
```bash
python code/interactive.py --user user_01 --amount 15000 --date 2026-03-01 --desired 2026-03-31
```
Or run interactively without arguments to be prompted step-by-step:
```bash
python code/interactive.py
```

---

## 2. Architecture & Modules

The system is organized into modular, deterministic, and interpretable layers:

- **`data_loader.py`**: Loads structured profiles, transactions, dated fixed exchange rates, options, parsed messages, and multimodal visual facts.
- **`multimodal.py`**: High-precision visual evidence extractor for missing transaction amounts in `dataset/media/images/`.
- **`message_parser.py`**: Contextual communication engine extracting contract status, salary date shifts, compensation adjustments, and active failed debits.
- **`forecaster.py`**: 90-day conservative cashflow simulation engine modeling daily balances, recurring living expenses, verified salary inflows, and pending debit reserves.
- **`optimizer.py`**: Evaluates candidate options (`full_payment`, `partial_payment`, `installments`, `wait`, permitted spending changes, `not_recommended`), enforcing minimum balance constraints across the entire forecast window.
- **`ranker.py`**: Personalized candidate ranking conforming to the 7-tier decision hierarchy (deadline completion, status precedence, minimal spending cuts, lowest cost, earliest start, and fewest payments).
- **`explainer.py`**: Generates grounded, human-readable natural language justifications reflecting exact financial metrics.
- **`evaluation/usage_report.md`**: Complete token and model cost report for the full dataset run.

---

## 3. Output Schema

The generated `output.csv` strictly adheres to the challenge specification:
```text
request_id,amount_safe_to_pay,affordability_status,recommended_payment_method,payment_plan,earliest_date_for_full_payment,spending_changes_needed,decision_explanation
```
